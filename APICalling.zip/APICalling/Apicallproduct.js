var pid=document.getElementById('textid')
var pid2=document.getElementById('labelid')
var ptitle=document.getElementById('labeltitle')
var pdisc=document.getElementById('labeldiscription')
var pprice=document.getElementById('labelprice')
var pimg=document.getElementById('imgpic')
var maindiv=document.getElementById('maindiv')



function callproductapi(){      
    var url='https://dummyjson.com/products/'+pid.value
    var request=new XMLHttpRequest;
    request.open('GET',url,true);
    request.onload=apicallResponseCallBack;
    ///start api calling using send method
    request.send();

}
//for taking response from server
function apicallResponseCallBack(){
    // alert(this.responseText)
    // maindiv.innerText= this.responseText
    var jsobject=JSON.parse(this.responseText)
    pid2.innerText=jsobject.id;
    ptitle.innerText=jsobject.title;
    pdisc.innerText=jsobject.discription;
    pprice.innerText=jsobject.price;
    pimg.src=jsobject.thumbnail;

}